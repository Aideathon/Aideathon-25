import React, { useState } from "react"
import { motion } from "framer-motion"
import Card from "../components/Card"
import API from "../services/api"
import EmojiIcon from "../components/EmojiIcon";

export default function Contact() {
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [subject, setSubject] = useState("")
  const [message, setMessage] = useState("")
  const [err, setErr] = useState("")

  async function submit(e) {
    e.preventDefault()
    setErr("")
    if (!name || !email || !subject || !message) {
      setErr("{/*emoji*/}<EmojiIcon char="⚠" />️ All fields required")
      return
    }
    try {
      await API.post("/contacts/", { name, email, subject, message })
      alert("{/*emoji*/}<EmojiIcon char="✅" /> Message sent successfully")
      setName("")
      setEmail("")
      setSubject("")
      setMessage("")
    } catch (err) {
      console.error(err)
      setErr("{/*emoji*/}<EmojiIcon char="❌" /> Failed to send message. Please try again later.")
    }
  }

  return (
    <motion.div
      style={{ padding: "40px 0" }}
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <h2 style={{ textAlign: "center", marginBottom: 32 }}>{/*emoji*/}<EmojiIcon char="📩" /> Contact Organizers</h2>

      <div className="contact-grid" style={{ display: "grid", gap: 24, gridTemplateColumns: "1fr 1fr" }}>
        {/* Contact Form */}
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card>
            <form onSubmit={submit} style={{ display: "grid", gap: 16 }}>
              <input
                className="input"
                placeholder="Full Name"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
              <input
                className="input"
                placeholder="Email Address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              <input
                className="input"
                placeholder="Subject"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
              />
              <textarea
                className="input"
                placeholder="Write your message..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                rows={6}
              />
              {err && <div style={{ color: "#b91c1c", fontSize: 14 }}>{err}</div>}
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="cta-btn"
                type="submit"
                style={{ alignSelf: "end" }}
              >
                {/*emoji*/}<EmojiIcon char="🚀" /> Send Message
              </motion.button>
            </form>
          </Card>
        </motion.div>

        {/* Organizer Info */}
        <motion.div
          className="contact-card"
          style={{
            background: "var(--card)",
            borderRadius: 12,
            padding: 20,
            boxShadow: "var(--shadow)",
          }}
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
        >
          <h3>{/*emoji*/}<EmojiIcon char="🏫" /> Department Details</h3>
          <p className="small">
            AI & Data Science Department <br />
            C. Abdul Hakeem College of Engineering and Technology
          </p>

          <h4 style={{ marginTop: 16 }}>{/*emoji*/}<EmojiIcon char="👥" /> Organizer Contacts</h4>
          <p><strong>Faculty Incharge:</strong> Mr. Senthil Kumar — senthilkumar@cahcet.edu.in</p>
          <p><strong>Student Incharge:</strong> Suresh Krishnan — +91 98765 43210 — suresh@example.com</p>
          <p><strong>Student Incharge:</strong> Kishor — +91 98765 43210 — kishor@example.com</p>

          <h4 style={{ marginTop: 16 }}>{/*emoji*/}<EmojiIcon char="📍" /> Office</h4>
          <p>
            C. Abdul Hakeem College of Engineering and Technology <br />
            Melvisharam, Vellore District
          </p>
        </motion.div>
      </div>
    </motion.div>
  )
}
