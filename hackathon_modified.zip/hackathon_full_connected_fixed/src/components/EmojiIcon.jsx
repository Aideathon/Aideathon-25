import React from "react";
import EmojiIcon from "./EmojiIcon";
// This component maps a few common emojis to lucide-react icons.
// It gracefully falls back to rendering the raw character if lucide-react is not installed.
let Lucide;
try {
  // dynamic require so projects that don't have lucide-react won't crash at build-time here.
  Lucide = require("lucide-react");
} catch (e) {
  Lucide = null;
}

const mapping = {
  "{/*emoji*/}<EmojiIcon char="🔥" />": "Fire",
  "{/*emoji*/}<EmojiIcon char="😎" />": "Smile",
  "{/*emoji*/}<EmojiIcon char="🙂" />": "Smile",
  "{/*emoji*/}<EmojiIcon char="😊" />": "Smile",
  "{/*emoji*/}<EmojiIcon char="✨" />": "Sparkles",
  "{/*emoji*/}<EmojiIcon char="✅" />": "CheckCircle",
  "{/*emoji*/}<EmojiIcon char="📌" />": "MapPin",
  "{/*emoji*/}<EmojiIcon char="🎉" />": "PartyPopper", // fallback - lucide may not have this; handled below
  "{/*emoji*/}<EmojiIcon char="🔔" />": "Bell",
  "{/*emoji*/}<EmojiIcon char="⚙" />️": "Settings",
  "{/*emoji*/}<EmojiIcon char="📝" />": "Edit",
  "{/*emoji*/}<EmojiIcon char="📁" />": "Folder",
  "{/*emoji*/}<EmojiIcon char="❗" />": "AlertCircle",
  "{/*emoji*/}<EmojiIcon char="💡" />": "Lightbulb",
};

export default function EmojiIcon({ char, className = "icon", size = 16, title }) {
  const name = mapping[char];
  if (Lucide && name && Lucide[name]) {
    const Icon = Lucide[name];
    return <Icon size={size} className={className} title={title || char} />;
  }
  // Fallback: simple styled span
  return <span className={className} aria-hidden="true">{char}</span>;
}
